package com.naod.tiktokliverecorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.Environment
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecorderService : Service() {

    companion object {
        const val ACTION_START = "com.naod.tiktokliverecorder.START"
        const val ACTION_STOP = "com.naod.tiktokliverecorder.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "naod_recording"
        private const val NOTIFICATION_ID = 4107
    }

    private var recorder: MediaRecorder? = null
    private var projection: MediaProjection? = null
    private var output: File? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val data = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                if (data != null && code != 0) startRecording(code, data)
            }
            ACTION_STOP -> stopRecording()
        }
        return START_NOT_STICKY
    }

    private fun startRecording(resultCode: Int, data: Intent) {
        if (recorder != null) return

        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)

        val dir = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "NaodTikTok")
        dir.mkdirs()

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        output = File(dir, "NaodTikTok_LIVE_$stamp.mp4")

        try {
            recorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

            recorder?.apply {
                setVideoSource(MediaRecorder.VideoSource.SURFACE)
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setVideoSize(720, 1280)
                setVideoFrameRate(30)
                setVideoEncodingBitRate(5_000_000)
                setAudioEncodingBitRate(128_000)
                setAudioSamplingRate(44_100)
                setOutputFile(output!!.absolutePath)
                prepare()
            }

            val surface = recorder!!.surface

            // A practical v1 screen recorder uses MediaProjection's virtual display.
            projection?.createVirtualDisplay(
                "NaodTikTokRecorder",
                720,
                1280,
                resources.displayMetrics.densityDpi,
                0,
                surface,
                null,
                null
            )

            recorder?.start()
        } catch (e: Exception) {
            recorder?.release()
            recorder = null
            projection?.stop()
            projection = null
            stopSelf()
        }
    }

    private fun stopRecording() {
        try {
            recorder?.stop()
        } catch (_: Exception) {
        }
        recorder?.reset()
        recorder?.release()
        recorder = null

        projection?.stop()
        projection = null

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createChannel() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "NaodTikTok recording",
                NotificationManager.IMPORTANCE_LOW
            )
        )
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, RecorderService::class.java).setAction(ACTION_STOP)
        val pending = PendingIntent.getService(
            this,
            20,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("NaodTikTok Live Recorder")
                .setContentText("Recording screen…")
                .setSmallIcon(R.drawable.ic_launcher)
                .setOngoing(true)
                .addAction(Notification.Action.Builder(null, "STOP", pending).build())
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("NaodTikTok Live Recorder")
                .setContentText("Recording screen…")
                .setSmallIcon(R.drawable.ic_launcher)
                .setOngoing(true)
                .build()
        }
    }

    override fun onDestroy() {
        if (recorder != null) stopRecording()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
