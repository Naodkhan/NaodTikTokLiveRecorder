package com.naod.tiktokliverecorder

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var startButton: MaterialButton
    private lateinit var stopButton: MaterialButton

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasAudioPermission()) requestProjection()
            else status.text = "Microphone permission is required for this release."
        }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val service = Intent(this, RecorderService::class.java).apply {
                    action = RecorderService.ACTION_START
                    putExtra(RecorderService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(RecorderService.EXTRA_RESULT_DATA, result.data)
                }
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service)
                else startService(service)
                setRecordingUi(true)
            } else {
                status.text = "Screen-recording permission was cancelled."
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)

        startButton.setOnClickListener { beginRecording() }
        stopButton.setOnClickListener {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
            setRecordingUi(false)
        }
        findViewById<MaterialButton>(R.id.filesButton).setOnClickListener { openRecordings() }

        if (!Settings.canDrawOverlays(this)) {
            // No overlay is required; this check is intentionally not used.
        }
    }

    private fun beginRecording() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS

        val missing = permissions.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        } else {
            requestProjection()
        }
    }

    private fun requestProjection() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mgr.createScreenCaptureIntent())
    }

    private fun setRecordingUi(recording: Boolean) {
        startButton.isEnabled = !recording
        stopButton.isEnabled = recording
        status.text = if (recording)
            "🔴 Recording… TikTok LIVE can now be brought to the foreground."
        else
            "Ready — recording stopped."
    }

    private fun openRecordings() {
        val dir = File(getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES), "NaodTikTok")
        dir.mkdirs()
        val uri = Uri.fromFile(dir)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "*/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            status.text = "Recordings folder: ${dir.absolutePath}"
        }
    }
}
