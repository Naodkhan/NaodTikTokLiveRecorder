# NaodTikTok Live Recorder

Android 10+ starter project for recording a TikTok LIVE using Android MediaProjection.

## Features in v1
- MediaProjection screen recording
- H.264 video + AAC microphone audio
- Foreground recording service
- Internal app storage under Movies/NaodTikTok
- Start/Stop controls
- Android 13+ notification permission
- Dark NaodTikTok UI

## Build
Open this folder in Android Studio Ladybug or newer, let Gradle sync, then:
Build > Generate App Bundles or APKs > Generate APKs.

## Important Android limitation
This version uses the microphone for audio. Android may block playback capture of another app, and protected content cannot be captured. The app does not bypass TikTok or Android security restrictions.

For a production release, the next version should add:
- MediaStore public Movies/NaodTikTok saving
- recordings browser with thumbnails
- playback/share/delete UI
- orientation-aware resolution
- crash recovery
- optional AudioPlaybackCapture where the device/app permits it
- better notification and recording timer
