# Build the APK with GitHub — no Android Studio

1. Create a new GitHub repository named `NaodTikTokLiveRecorder`.
2. Upload **all files and folders inside this project** to the repository.
3. Commit to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build NaodTikTok Live Recorder APK**.
6. Click **Run workflow**.
7. Wait for the green check mark.
8. Open the completed workflow run.
9. Under **Artifacts**, download `NaodTikTokLiveRecorder-debug`.
10. Extract the downloaded ZIP and install `app-debug.apk` on your Android phone.

No Android Studio is required.

If GitHub asks to enable Actions, enable them for the repository.

The APK is a debug build intended for personal/testing use.
